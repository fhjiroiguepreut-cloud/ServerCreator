# Bedrock Server Creator

App gratuita para crear y gestionar servidores dedicados de Minecraft Bedrock
(mundos, addons, staff, moderación, comandos personalizados, respaldos en la nube).

## Ejecutar con Python
    python bedrock_server_creator.py      (Python 3.8+, sin dependencias)

## Compilar con GitHub Actions
1. Crea un repositorio y sube el contenido de esta carpeta (incluida `.github`).
2. Pestaña **Actions** -> **Build** -> **Run workflow**.
3. Al terminar, descarga el ejecutable en **Artifacts**:
   - `BedrockServerCreator-Windows` (.exe)
   - `BedrockServerCreator-Linux`
4. Para publicarlo en Releases, crea un tag `v1.0.0`.

Los servidores se guardan en `~/BedrockServers`.
